package com.training;

import java.util.HashSet;
import java.util.Scanner;

public class FirstRepeating {
   static void printFirstRepeating(int arr[]) {
	   int min = -1;
	   HashSet<Integer> set = new HashSet<>();
	   for(int i = arr.length-1; i>=0; i--) {
		   if(set.contains(arr[i])) {
			   min = i;
		   }else {
			   set.add(arr[i]);
		   }
			   
	   }
	   if(min != -1) {
		   System.out.println("The First Repeating Element is "+arr[min]);
	   }else {
		   System.out.println("There are no repeating elements");
	   }
   }
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter length of Array : ");
    int[] arr = new int[sc.nextInt()];
    System.out.println("Enter array values : ");
    for(int i = 0; i < arr.length; i++) {
    	arr[i] = sc.nextInt();
    }
	printFirstRepeating(arr);
	}
}
