package Problem_Statement3_2;

public class MedicineInfo{

public void displayLabel(){

System.out.println("Company : Medmax Pharma");System.out.println("Address : Hyderabad");

}}

class Tablet extends MedicineInfo{

public void displayLabel(){

System.out.println("store in a cool dry place");}

}

class Syrup extends MedicineInfo{

public void displayLabel(){

System.out.println("Shake Well before use");

}}

class Ointment extends MedicineInfo{

public void displayLabel(){

System.out.println("for external use only");}

}

