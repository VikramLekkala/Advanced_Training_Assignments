package Problem_Statement1_1;

public class ListAllEven {

	public static void main(String[] args) {
		int n=50;
		System.out.println("Even Numbers from 1 to "+n+" are:");
		for(int i=1;i<=n;i++) {
			if(i%2==0){//codition for even number
				System.out.println(i+" ");
				}
			}
			
	}

}
