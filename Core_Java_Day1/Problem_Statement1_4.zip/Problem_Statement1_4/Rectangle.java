package Problem_Statement1_4;

import java.util.Scanner;

public class Rectangle {
       float length;
		float width;
		float area;
		float perimeter;
		
		public float getLength() {
			return length;
		}
		public void setLength(float length) {
			this.length = length;
		}
		public float getwidth() {
			return width;
		}
		public void setwidth(float width) {
			this.width = width;
		}
		public Rectangle() {
		length=1;
		width=1;	
		}
		void input() {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter length of  Rectangle: ");
			length=sc.nextFloat();
			System.out.println("Enter width of  Rectangle: ");
			width=sc.nextFloat();
		}
		void areaOfRectangle() {
			area=length*width;
		}
		void perimeterOfRectangle() {
			perimeter=2*(length+width);
		}
		void display() {
			if(length>0.0 && length<20.0)
			System.out.println("Area of Rectangle = "+area);
			System.out.println("Perimeter of Rectangle = "+perimeter);
		}
		public static void main(String[] args) {
			//Object 1
		Rectangle obj1=new Rectangle();
		System.out.println("Object 1 Information");
		obj1.input();
		obj1.areaOfRectangle();
		obj1.perimeterOfRectangle();
		obj1.display();
		//Object 2
		Rectangle obj2=new Rectangle();
		System.out.println("Object 2 Information");
		obj2.input();
		obj2.areaOfRectangle();
		obj2.perimeterOfRectangle();
		obj2.display();
		//Object 3
		Rectangle obj3=new Rectangle();
		System.out.println("Object 3 Information");
		obj3.input();
		obj3.areaOfRectangle();
		obj3.perimeterOfRectangle();
		obj3.display();
		//Object 4
		Rectangle obj4=new Rectangle();
		System.out.println("Object 4 Information");
		obj4.input();
		obj4.areaOfRectangle();
		obj4.perimeterOfRectangle();
		obj4.display();
		//Object 5
		Rectangle obj5=new Rectangle();
		System.out.println("Object 5 Information");
		obj5.input();
		obj5.areaOfRectangle();
		obj5.perimeterOfRectangle();
		obj5.display();
	}

}
