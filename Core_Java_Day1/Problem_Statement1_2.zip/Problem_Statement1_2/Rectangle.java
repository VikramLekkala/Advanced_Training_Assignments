package Problem_Statement1_2;

import java.util.Scanner;

public class Rectangle {
       int length;
		int breadth;
		int area;
		public Rectangle() {
		length=0;
		breadth=0;	
		}
		void input() {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter length of  Rectangle: ");
			length=sc.nextInt();
			System.out.println("Enter breadth of  Rectangle: ");
			breadth=sc.nextInt();
		}
		void calculate() {
			area=length*breadth;
		}
		void display() {
			System.out.println("Area of Rectangle = "+area);
		}
		public static void main(String[] args) {
			//Object 1
		Rectangle obj1=new Rectangle();
		System.out.println("Object 1 Information");
		obj1.input();
		obj1.calculate();
		obj1.display();
		//Object 2
		Rectangle obj2=new Rectangle();
		System.out.println("Object 2 Information");
		obj2.input();
		obj2.calculate();
		obj2.display();
		//Object 3
		Rectangle obj3=new Rectangle();
		System.out.println("Object 3 Information");
		obj3.input();
		obj3.calculate();
		obj3.display();
		//Object 4
		Rectangle obj4=new Rectangle();
		System.out.println("Object 4 Information");
		obj4.input();
		obj4.calculate();
		obj4.display();
		//Object 5
		Rectangle obj5=new Rectangle();
		System.out.println("Object 5 Information");
		obj5.input();
		obj5.calculate();
		obj5.display();
	}

}
